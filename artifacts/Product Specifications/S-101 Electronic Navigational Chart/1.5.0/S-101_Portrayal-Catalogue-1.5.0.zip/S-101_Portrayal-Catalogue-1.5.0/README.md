# S-101 Portrayal-Catalogue
IHO S-101 Portrayal Catalogue development, discussion, and review

[i3]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/3
[i8]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/8
[i17]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/17
[i99]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/99
[i144]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/144
[i157]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/157
[i175]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/175
[i177]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/177
[i204]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/204
[i214]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/214
[i224]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/224
[i226]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/226
[i228]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/228
[i229]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/229
[i238]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/238
[i272]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/272
[i273]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/273
[i274]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/274
[i276]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/276
[i277]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/277
[i278]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/278
[i279]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/279
[i280]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/280
[i281]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/281
[i282]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/282
[i285]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/285
[i287]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/287
[i288]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/288
[i289]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/289
[i290]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/290
[i291]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/291
[i292]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/292
[i293]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/293
[i294]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/294
[i295]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/295
[i296]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/296
[i297]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/297
[i298]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/298
[i299]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/299
[i300]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/300
[i301]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/301
[i302]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/302
[i303]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/303
[i307]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/307
[i305]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/305
[i304]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/304
[i306]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/306
[i309]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/309
[i311]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/311
[i312]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/312
[i313]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/313
[i316]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/316
[i318]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/318
[i319]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/319
[i320]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/320
[i321]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/321
[i322]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/322
[i323]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/323
[i324]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/324
[i325]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/325
[i326]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/326
[i327]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/327
[i329]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/329
[i330]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/330
[i331]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/331
[i332]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/332
[i333]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/333
[i334]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/334
[i335]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/335
[i336]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/336
[i337]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/337
[i338]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/338
[i340]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/340
[i341]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/341
[i342]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/342
[i344]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/344
[i345]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/345
[i346]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/346
[i347]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/347
[i348]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/348
[i349]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/349
[i350]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/350
[i351]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/351
[i352]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/352
[i353]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/353
[i354]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/354
[i355]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/355
[i356]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/356
[i358]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/358
[i359]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/359
[i360]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/360
[i361]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/361
[i365]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/365
[i366]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/366
[i367]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/367
[i368]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/368
[i371]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/371
[i372]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/372
[i373]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/373
[i374]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/374
[i375]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/375
[i376]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/376
[i377]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/377
[i378]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/378
[i379]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/379
[i380]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/380
[i381]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/381
[i382]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/382
[i383]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/383
[i384]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/384
[i387]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/387
[i346]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/346
[i386]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/386
[i388]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/388
[i389]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/389
[i390]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/390
[i391]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/391
[i392]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/392
[i393]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/393
[i394]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/394
[i395]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/395
[i396]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/396
[i397]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/397
[i398]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/398
[i399]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/399
[i400]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/400
[i401]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/401
[i404]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/404
[i405]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/405
[i406]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/406
[i409]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/409
[i410]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/410
[i411]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/411
[i412]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/412
[i413]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/413
[i414]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/414
[i415]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/415
[i416]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/416
[i417]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/417
[i418]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/418
[i419]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/419
[i420]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/420
[i421]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/421
[i422]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/422
[i423]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/423
[i424]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/424
[i426]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/426
[i428]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/428
[i429]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/429
[i431]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/431
[i432]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/432
[i433]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/433
[i436]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/436
[i437]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/437
[i438]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/438
[i439]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/439
[i440]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/440
[i441]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/441
[i442]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/442
[i443]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/443
[i444]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/444
[i445]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/445
[i446]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/446
[i447]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/447
[i427]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/427
[i448]: https://github.com/iho-ohi/S-101_Portrayal-Catalogue/issues/448

## Recent changes
Older changes are here: [Changelog.md](Changelog.md)

### 1.5.X - use with FC 1.5.X
* Misc changes
 	* [#422][i422] Update PC version to "1.5.0-DRAFT"
	* [#431][i431] Remove DEPVAL02, no longer used
 	* [#429][i429] Remove viewing group layer 10a
  	* [#439][i439] Rename (text) viewing group 23 to "Text: Aids to Navigation information"
 	* [#427][i427] Update PC version to "1.5.0" prior to release
	* [#448][i448] Remove unofficial courtesy copy of FC from PC release

* Lua Rule File / Symbol Updates
 	* [#433][i433] MooringArea Point geometry in wrong display plane when radar is off
 	* [#432][i432] Clearance label on Gate can overwrite curve
  	* [#424][i424] Deconflict labels on co-located lights
	* [#428][i428] HasHorizontalClearance() always returns true, shorten return logic
	* [#437][i437] Multiplicity of attribute category of dolphin
	* [#438][i438] DredgedArea remove "dredged to" text
	* [#437][i437] re-opened, Deviation Dolphin has priority
 	* [#444][i444] Junction cable portrayed incorrectly
  	* [#440][i440] Remove line styles LOWACC01, LOWACC11 and symbols EMLOWAC01, EMLOWAC11
  	* [#441][i441] `CableSubmarine` should alert on `categoryOfCable`=`9 - Junction Cable` rather than `6 - Mooring Cable`
  	* [#436][i436] Add NavHazard alert to `Obstruction` when `waterLevelEffect`=`7 - Floating`
  	* [#446][i446] Add NavHazard alert to `Obstruction` when `categoryOfObstruction`=`21 - Active Submarine Volcano`
  	* [#447][i447] Active submarine volcano uses new viewing group `14020` "Non-isolated dangers (active submarine volcanos)"
  	* [#442][i442] Junction cables: update viewing group description for `14020` and `24010`
  	* [#443][i443] Ferry cables: update viewing group description for `24010`

### 1.4.0 - use with FC 1.4.1
* Misc changes
	* [#391][i391] Update main version number to 1.4.0-DRAFT
 	* [#390][i390] Remove "dock (DOCARE)" from name of viewing group `12420`
  	* [#393][i393] Update FC to 1.3.1
  	* [#157][i157] Update contents for utf-8 encoding
  	* [#404][i404] Remove `testPCB`
  	* [#405][i405] Update FC to 1.4.0 dated 2024-07-03
  	* [#410][i410] Remove alert catalog references to non-existent icons
  	* [#414][i414] Remove the alert viewing group layer and implement alert viewing groups as independent selectors
  	* [#415][i415] Message associated with disablement of graphical highlight of ProhAre alerts changed to "Indication of some prohibited areas or areas with special conditions is Off"
  	* [#419][i419] Change name of viewing group `21020` from "Generic object (NEWOBJ01)" to "Chart 1 feature, virtual AIS aid to navigation"
  	* [#420][i420] Update FC to reflect changes expected in 1.4.1
  	* [#8][i8] Update catalog and rules with (expected) xmlID's from portrayal registry
  	* [#426][i426] Update FC to 1.4.1
	* [#421][i421] Update PC version from "1.4.0-DRAFT" to final release 1.4.0

* Lua Rule File / Symbol Updates
	* [#382][i382] Landmark featureName placement differs for simplified/traditional
 	* [#394][i394] `TextPlacement` is not copying all relevant drawing instructions
  	* [#395][i395] Enhance `TextPlacement` to support output of multiple strings
  	* [#396][i396] Update alignment of `TextPlacement` per S-101PT13-07.8
  	* [#399][i399] Add comment to TextPlacement.lua noting implementation location
  	* [#361][i361] `flareBearing` is not required; reinstate S-52 flare bearing logic
  	* [#400][i400] Removed point as allowable geometry for `FloatingDock`
  	* [#401][i401] Removed point as allowable geometry for `Pontoon`
  	* [#392][i392] `DistanceMark` portrays using symbol `DISMAR07` when visible with no structure
  	* [#411][i411] Fix typo in `CreateAttributeConstraints`
  	* [#412][i412] Add compatibility checks for Lua versions other than 5.1
  	* [#413][i413] `SeaAreaNamedWaterArea` should always output NullInstruction
  	* [#376][i376] Add light description on sector lights
  	* [#397][i397] Enhance `TextPlacement` to support placing feature characteristics
  	* [#398][i398] Support combined `TextPlacement` per S-101PT13-07.8
  	* [#409][i409] `no chart display (3)` is no longer valid for `nameUsage`
  	* [#416][i416] Implement `scaleMinimum` for `TextPlacement`
  	* [#418][i418] TOPMAR02 undefined for `EmergencyWreckMarkingBuoy` and `IsolatedDangerBuoy`
  	* [#417][i417] Depict horizontal clearance values
  	* [#389][i389] Added `Chart1Feature`
  	* [#406][i406] Enhanced error checks for `UpdateInformation`
  	* [#423][i423] TrafficSeparationSchemeLanePart only displays english text
 

### 1.3.0 - use with FC 1.3.0
* Misc changes
	* [#346][i346] Update version prior to release 1.3.X, initial version
	* [#348][i348] SVG <fileName> duplication, BOYCON30.svg ---> BOYCON31.svg
	* [#345][i345] Remove svg from CSS files
 	* [#353][i353] Update description of viewing group `22010` to include `DockArea`
  	* [#381][i381] Remove older changes from README
  	* [#342][i342] Update branch catzoc-alternate-portrayals
  	* [#346][i346] Prepare for 1.3.0-PR (Peer Review)
	* [#388][i388] Update version from 1.3.0-PR to final release 1.3.0 after peer review

* Lua Rule File / Symbol Updates
	* [#349][i349] Fix metadata validation issues in multiple symbols
 	* [#350][i350] Remove catalog entry for unused symbol EMNEWOB1.svg
  	* [#347][i347] `DiscolouredWater` doesn't trigger indication
  	* [#354][i354] Incorrect text offset in `CardinalBuoy` when `buoyShape` is `Superbuoy (7)`
	* [#340][i340] Remove converter comments from rule files
	* [#356][i356] BeaconLateral bug, updated to beaconShape == 4	
	* [#316][i316] Incorporate new EWMB 'Paper Chart' symbols [PSWG #158]	
	* [#344][i344] MooringArea problems bug fix
	* [#367][i367] No date dependent symbol on "no geometry" features [PSWG #161, Row 30]
 	* [#351][i351] Ensure all symbols reference a valid default stylesheet
  	* [#352][i352] Ensure all symbols have an entry in portrayal_catalogue.xml
  	* [#355][i355] New symbology for Waterfall features of type Point
  	* [#371][i371] Update association role codes for FC 1.3
  	* [#368][i368] Portray attribute "communicationChannel" for `RadarStation` and `RadioCallingInPoint`
  	* [#358][i358] Use 50% translucent fill for `IceArea`
  	* [#373][i373] Remove LineStyle `PILDSTR1`
  	* [#374][i374] `SpanOpening` should show `clr op ∞` when `verticalClearanceUnlimited` is `true`
  	* [#375][i375] `QoBD` shows multiple date dependent symbols
  	* [#359][i359] Add thin orange line to `UpdateInformation` delete of curve or surface
  	* [#331][i331] Show thin dashed orange line for `UpdateInformation` with `updateType`=`4 (move)` and curve geometry
  	* [#372][i372] Implement portrayal of Incompletely Surveyed Area
  	* [#366][i366] Show vertical clearance on `Gate`
  	* [#177][i177] Remove CSS inline styling from all symbols
  	* [#204][i204] Update symbols for S-100 5.2 SVG schema
  	* [#377][i377] Update area fills for S-100 5.2 schema
  	* [#378][i378] Update line styles for S-100 5.2 schema
  	* [#379][i379] Update alert catalog for S-100 5.2 schema
  	* [#380][i380] Update portrayal_catalogue.xml for S-100 5.2 schema
  	* [#361][i361] Use `flareBearing` attribute in lieu of S-52 rule for colocated lights
  	* [#383][i383] Reduce line weight for `BOYPIL60`, `BOYSPH50`, `BOYSPH60` and `BOYSPR60`
  	* [#384][i384] Fix outline color for `BOYPIL60`, `BOYSPH50`, `BOYSPH60` and `BOYSPR60` to support dusk and night palettes
  	* [#360][i360] Implement portrayal for `StructureOverNavigableWater`
  	* [#365][i365] “system” attribute in the water, [PSWG #161, Row 21]
  	* [#387][i387] `BOYPIL60` has extraneous circles
 	* [#386][i386] Problems with MooringArea
